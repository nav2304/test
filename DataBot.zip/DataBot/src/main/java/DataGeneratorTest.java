import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.automation.datagenerator.main.DataGenerator;

/**
 * ###################################################################################
 * 
 * @Filename : dataTest.java
 * @Author : Vaijnath @time 6:32:01 PM
 * @Purpose : TODO
 * @CreationDate : Jan 13, 2019
 * @Package :
 *          ###################################################################################
 **/

/**
 * ###################################################################################
 * 
 * @Name : dataTest
 * @Author : Vaijnath
 * @Purpose : TODO
 * @CreationDate : Jan 13, 2019 6:32:01 PM
 * @Package :
 *          ###################################################################################
 **/
public class DataGeneratorTest {

	/**
	 * ###################################################################################
	 * 
	 * @throws IOException
	 * 
	 * @Name : main
	 * @Purpose : Test Scenario For DataGeneration
	 * @Parameters : @param args
	 * @ReturnType : void
	 * @Author : Vaijnath
	 * @CreationDate : Jan 13, 2019 6:32:01 PM
	 * @Modification :
	 *               ###################################################################################
	 **/

	public static void main(String[] args) throws IOException {
		Pattern regex = null;
		Matcher match = null;
		// Read properties file in sequence
		Map<String, String> properties = new LinkedHashMap<String, String>() {
			private static final long serialVersionUID = -8293681035586005982L;
			{
				try (Stream<String> stream = Files.lines(Paths.get("TradeEntry.properties"))) {
					stream.collect(Collectors.toList()).forEach(s -> {
						if (!(s.toLowerCase().startsWith("#") || s.trim().equals(""))) // Comments to be added on line
																						// starting with #
							put(s.split("=")[0], s.split("=")[1]);
					});
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		};

		int count = Integer.parseInt(properties.get("count"));
		properties.remove("count");
		for (String key : properties.keySet()) {
			System.out.printf("%-25s | ", key);
		}
		System.out.println();

		// TODO - SSN Save to cache file if not repeatable
		// TODO - UI Creation
		// TODO - SAMPLE DATA FOR CMR Customer Creation fields and FXOL3 Contract Fields
		// TODO - Report TO file

		DataGenerator dataGenerator = new DataGenerator();
		regex = Pattern.compile("\\$\\{[A-z,.]+\\}");
		List<Map<String, String>> datalist = new ArrayList<Map<String, String>>();
		String data = null;
		for (int i = 0; i < count; i++) {
			Map<String, String> dataMap = new HashMap<String, String>();
			for (String key : properties.keySet()) {
				String[] parseExpression = properties.get(key).split(":");

				switch (parseExpression[0].toLowerCase().trim()) {
				case "ssn_number":
					data = dataGenerator.ssn_number().ssnValid();
					break;
				case "constant":
					data = parseExpression[1];
					break;
				case "expression":
				case "key":
					data = dataGenerator.parseExpression(parseExpression[1].trim());
					break;
				case "format":
					data = dataGenerator.generateCharAndNumbers(parseExpression[1].trim());
					break;
				case "regex":
				case "regular expression":
					data = dataGenerator.generateStringForRegEx(parseExpression[1].trim());
					break;
				case "number between":
					String value = parseExpression[1].replace("(", "").replace(")", "");
					data = String.valueOf(dataGenerator.number().numberBetween(
							Long.parseLong(value.split(",")[0].trim()), Long.parseLong(value.split(",")[1].trim())));
					break;
				case "number less than":
					data = String.valueOf(
							dataGenerator.number().numberBetween(0, Long.parseLong(parseExpression[1].trim())));
					break;
				case "number greater than":
					data = String.valueOf(dataGenerator.number()
							.numberBetween(Long.parseLong(parseExpression[1].trim()), Long.MAX_VALUE));
					break;
				case "past date":
					data = String.valueOf(dataGenerator.getDateTime().past(10 * 360, TimeUnit.DAYS));
					break;
				case "future date":
					data = String.valueOf(dataGenerator.getDateTime().future(10 * 360, TimeUnit.DAYS));
					break;
				case "date between":

					break;
				default:
					System.out.format("%-25s | ", dataGenerator.parseExpression(properties.get(key)));
				}
				System.out.format("%-25s | ", data);
				dataMap.put(key, data);
			}
			datalist.add(dataMap);
			System.out.println();
		}
		List<String> lines = new ArrayList<String>();
		for (Map<String, String> datacols : datalist) {
			lines.add(StringUtils.join(datacols.values(), ","));
		}
		String fileName = "DataOutput" + dataGenerator.generateCharAndNumbers("########") + ".csv";
		System.out.println(fileName);
		Files.write(Paths.get("DataOutput" + fileName + ".csv"), lines, StandardCharsets.UTF_8,
				StandardOpenOption.CREATE_NEW, StandardOpenOption.APPEND);
	}
}