package com.automation.datagenerator;

import java.util.Arrays;

public enum ValidExpressions {
	Expression("Expression"), RegularExpression("Regular Expression"), SSNNumber("SSN Number"), DataDictionary("Data Dictionary"), Numbers("Numbers"), Dates("Dates"), DataRelation("Data Relation"), Format("Format");	
	private String value;
	
	/**
	 * 
	 * ###################################################################################
	 * 
	 * @Name : ValidExpressions -- Constructor
	 * @Purpose : TODO
	 * @Parameters : @param value
	 * @Returns : ValidExpressions
	 * @Author : Vaijnath Palwade
	 * @CreationDate : Mar 4, 2019 3:13:34 AM
	 * @Modification : NA
	 *               ###################################################################################
	 *
	 */
	ValidExpressions(String value) {
		this.value = value;
	}
	
	/**
	 * 
	 * ###################################################################################
	 * 
	 * @Name : getUrl
	 * @Purpose : TODO
	 * @Parameters : @return
	 * @ReturnType : String
	 * @Author : Vaijnath Palwade
	 * @CreationDate : Mar 4, 2019 3:13:29 AM
	 * @Modification :
	 *               ###################################################################################
	 *
	 */
	public String getValue() {
		return value;
	}
	
	/**
	 * 
	 * ###################################################################################
	 * 
	 * @Name : getAllValues
	 * @Purpose : TODO
	 * @Parameters : @param e
	 * @Parameters : @return
	 * @ReturnType : String[]
	 * @Author : Vaijnath Palwade
	 * @CreationDate : Mar 4, 2019 3:13:23 AM
	 * @Modification :
	 *               ###################################################################################
	 *
	 */
	public static String[] getAllValues(Class<? extends Enum<?>> e) {
		return Arrays.stream(e.getEnumConstants()).map(key -> ((ValidExpressions) key).getValue()).toArray(String[]::new);
	}
	
	public static ValidExpressions fromString(String text) {
		for (ValidExpressions v : ValidExpressions.values()) {
			if (v.value.equalsIgnoreCase(text)) {
				return v;
			}
		}
		return null;
	}
}
