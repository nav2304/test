package com.automation.datagenerator.gui;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class MainWindow {
	
	private JFrame dataBot;
	private JTable tableFields;
	private JTable tableData;
	
	/**
	 * 
	 * ###################################################################################
	 * 
	 * @Name : main
	 * @Purpose : TODO
	 * @Parameters : @param args
	 * @ReturnType : void
	 * @Author : palwadevm
	 * @CreationDate : Feb 19, 2019 2:02:34 AM
	 * @Modification :
	 *               ###################################################################################
	 *
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow window = new MainWindow();
					window.dataBot.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * 
	 * ###################################################################################
	 * 
	 * @Name : MainWindow -- Constructor
	 * @Purpose : window initialization
	 * @Parameters :
	 * @Returns : MainWindow
	 * @Author : palwadevm
	 * @CreationDate : Feb 19, 2019 2:02:44 AM
	 * @Modification : NA
	 *               ###################################################################################
	 *
	 */
	public MainWindow() {
		initialize();
	}
	
	/**
	 * 
	 * ###################################################################################
	 * 
	 * @Name : initialize
	 * @Purpose : Initialize window
	 * @Parameters :
	 * @ReturnType : void
	 * @Author : Vaijnath Palwade
	 * @CreationDate : Feb 19, 2019 2:06:59 AM
	 * @Modification :
	 *               ###################################################################################
	 *
	 */
	private void initialize() {
		dataBot = new JFrame();
		dataBot.setResizable(false);
		dataBot.setFont(new Font("Cantarell Light", Font.PLAIN, 10));
		dataBot.getContentPane().setFont(new Font("Carnas Light", Font.PLAIN, 10));
		dataBot.getContentPane().setLayout(null);
		
		JLabel lblProfileName = new JLabel("Profile Name: ");
		lblProfileName.setBounds(338, 0, 65, 14);
		lblProfileName.setFont(new Font("Cantarell Light", Font.PLAIN, 11));
		dataBot.getContentPane().add(lblProfileName);
		
		JLabel lblSaveStatus = new JLabel("not saved");
		lblSaveStatus.setBounds(408, 0, 54, 15);
		lblSaveStatus.setFont(new Font("Carnas Light", Font.BOLD, 11));
		dataBot.getContentPane().add(lblSaveStatus);
		
		JButton btnGenerateData = new JButton("Generate Data");
		btnGenerateData.setBounds(32, 235, 114, 25);
		btnGenerateData.setFont(new Font("Cantarell Light", Font.BOLD, 10));
		dataBot.getContentPane().add(btnGenerateData);
		
		JButton btnExportToExcel = new JButton("Export To File");
		btnExportToExcel.setFont(new Font("Cantarell Light", Font.BOLD, 10));
		btnExportToExcel.setBounds(158, 235, 114, 25);
		dataBot.getContentPane().add(btnExportToExcel);
		
		JButton btnExportToDatabase = new JButton("Export To DB (TBD)");
		btnExportToDatabase.setEnabled(false);
		btnExportToDatabase.setFont(new Font("Cantarell Light", Font.BOLD, 10));
		btnExportToDatabase.setBounds(282, 235, 137, 25);
		dataBot.getContentPane().add(btnExportToDatabase);
		
		JPanel panelFields = new JPanel();
		panelFields.setBorder(new TitledBorder(null, "Fields", TitledBorder.LEADING, TitledBorder.TOP, new Font("Cantarell Light", Font.BOLD, 10), null));
		panelFields.setBounds(22, 7, 760, 216);
		dataBot.getContentPane().add(panelFields);
		panelFields.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 17, 750, 194);
		panelFields.add(scrollPane);
		
		String[] columns = new String[] { "Field Name", "Type", "condition", "Option 1", "Option 2" };
		Object[][] newRow = new Object[][]{ { "", "", "", "", "" } };
		tableFields = new JTable(newRow, columns);
		DefaultTableModel tableModel = new DefaultTableModel(newRow, columns);
		tableFields.setModel(tableModel);
		scrollPane.setViewportView(tableFields);
		//		Set Cell Editors.
		DefaultCellEditor cellEditor = new DefaultCellEditor(new JTextField());
		cellEditor.setClickCountToStart(1);
		
		cellEditor.addCellEditorListener(new CellEditorListener() {
			public void editingCanceled(ChangeEvent e) {
				System.out.println("Editing Canceled: " + e);
			}
			
			public void editingStopped(ChangeEvent e) {
				tableFields.setValueAt(((DefaultCellEditor) e.getSource()).getCellEditorValue(), tableFields.getSelectedRow(), 0);
				newRow[tableFields.getSelectedRow()][0] = tableFields.getValueAt(tableFields.getSelectedRow(), 0);
			}
		});
		tableFields.getColumnModel().getColumn(0).setCellEditor(cellEditor);
		tableFields.getModel().addTableModelListener(new TableModelListener() {
			@Override
			public void tableChanged(TableModelEvent e) {
				TableModel tm = tableFields.getModel();
				DefaultTableModel dtm = (DefaultTableModel) tm;
				dtm.addRow(new Object[][]{ { "", "", "", "", "" } });
			}
		});
		
		JPanel panelData = new JPanel();
		panelFields.setBorder(new TitledBorder(null, "Data", TitledBorder.LEADING, TitledBorder.TOP, new Font("Cantarell Light", Font.BOLD, 10), null));
		panelData.setBounds(25, 266, 757, 222);
		dataBot.getContentPane().add(panelData);
		panelData.setLayout(null);
		
		JScrollPane scrollPaneData = new JScrollPane();
		scrollPaneData.setBounds(5, 12, 740, 198);
		panelData.add(scrollPaneData);
		
		tableData = new JTable();
		scrollPaneData.setViewportView(tableData);
		
		tableData.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null } }, new String[] { "userId", "ssnNumber", "firstName", "lastName", "joiningDate", "isActive", "loginDate" }));
		dataBot.setBounds(100, 100, 800, 551);
		dataBot.setTitle("DataBot v1.0");
		//		dataBot.setIconImage(Toolkit.getDefaultToolkit().getImage("resources/databot2.gif"));
		dataBot.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFont(new Font("Cantarell Light", Font.PLAIN, 11));
		menuBar.setToolTipText("Databot menu");
		dataBot.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("DataBot");
		mnNewMenu.setFont(new Font("Cantarell Light", Font.PLAIN, 11));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmLoadProfile = new JMenuItem("Load Profile");
		mntmLoadProfile.setFont(new Font("Cantarell Light", Font.PLAIN, 11));
		mnNewMenu.add(mntmLoadProfile);
		
	}
}
