package com.automation.datagenerator.main;

import java.util.Locale;
import java.util.Random;
import com.automation.datagenerator.main.dataUtils.DataService;
import com.automation.datagenerator.main.dataUtils.RandomService;
import com.automation.datagenerator.main.rules.Address;
import com.automation.datagenerator.main.rules.Color;
import com.automation.datagenerator.main.rules.DateAndTime;
import com.automation.datagenerator.main.rules.Name;
import com.automation.datagenerator.main.rules.Number;
import com.automation.datagenerator.main.rules.PhoneNumber;
import com.automation.datagenerator.main.rules.SSNNumber;

/**
 * 
 * ###################################################################################
 * 
 * @Name : DataGenerator
 * @Author : Vaijnath
 * @Purpose : Data Randomizer function
 * @CreationDate : Jan 14, 2019 3:29:09 AM
 * @Package : com.automation.datagenerator.main
 *          ###################################################################################
 *
 */
public class DataGenerator {
	private final RandomService randomService;
	private final DataService dataService;
	
	private final Name name;
	private final Number number;
	private final PhoneNumber phoneNumber;
	private final Address address;
	private final Color color;
	private final SSNNumber ssn_number;
	
	private final DateAndTime dateTime;
	
	public DataGenerator() {
		this(Locale.ENGLISH);
	}
	
	public DataGenerator(Locale locale) {
		this(locale, null);
	}
	
	public DataGenerator(Random random) {
		this(Locale.ENGLISH, random);
	}
	
	public DataGenerator(Locale locale, Random random) {
		this.randomService = new RandomService(random);
		this.dataService = new DataService(locale, randomService);
		this.name = new Name(this);
		this.phoneNumber = new PhoneNumber(this);
		this.address = new Address(this);
		this.color = new Color(this);
		this.ssn_number = new SSNNumber(this, true);
		this.number = new Number(this);
		this.dateTime = new DateAndTime(this);
	}
	
	/**
	 * Constructs DataGenerator instance with default argument.
	 *
	 * @return {@link DataGenerator#data()}
	 */
	public static DataGenerator instance() {
		return new DataGenerator();
	}
	
	/**
	 * Constructs DataGenerator instance with provided {@link Locale}.
	 *
	 * @param locale
	 *            - {@link Locale}
	 * @return {@link DataGenerator#data(Locale)}
	 */
	public static DataGenerator instance(Locale locale) {
		return new DataGenerator(locale);
	}
	
	/**
	 * Constructs DataGenerator instance with provided {@link Random}.
	 *
	 * @param random
	 *            - {@link Random}
	 * @return {@link DataGenerator#data(Random)}
	 */
	public static DataGenerator instance(Random random) {
		return new DataGenerator(random);
	}
	
	/**
	 * Constructs DataGenerator instance with provided {@link Locale} and {@link Random}.
	 *
	 * @param locale
	 *            - {@link Locale}
	 * @param random
	 *            - {@link Random}
	 * @return {@link DataGenerator#data(Locale, Random)}
	 */
	public static DataGenerator instance(Locale locale, Random random) {
		return new DataGenerator(locale, random);
	}
	
	/**
	 * Returns a string with the '#' characters in the parameter replaced with random digits between 0-9 inclusive.
	 * <p>
	 * For example, the string "ABC##EFG" could be replaced with a string like "ABC99EFG".
	 *
	 * @param numberString
	 * @return
	 */
	public String generateDigits(String numberString) {
		return dataService.numerify(numberString);
	}
	
	/**
	 * Returns a string with the '?' characters in the parameter replaced with random alphabetic
	 * characters.
	 * <p>
	 * For example, the string "12??34" could be replaced with a string like "12AB34".
	 *
	 * @param letterString
	 * @return
	 */
	public String generateChars(String letterString) {
		return dataService.letterify(letterString);
	}
	
	/**
	 * Returns a string with the '?' characters in the parameter replaced with random alphabetic
	 * characters.
	 * <p>
	 * For example, the string "12??34" could be replaced with a string like "12AB34".
	 *
	 * @param letterString
	 * @param isUpper
	 * @return
	 */
	public String generateChars(String letterString, boolean isUpper) {
		return dataService.letterify(letterString, isUpper);
	}
	
	/**
	 * Applies both a {@link #generateDigits(String)} and a {@link #generateChars(String)}
	 * over the incoming string.
	 *
	 * @param string
	 * @return
	 */
	public String generateCharAndNumbers(String string) {
		return dataService.bothify(string);
	}
	
	/**
	 * Applies both a {@link #generateDigits(String)} and a {@link #generateChars(String)}
	 * over the incoming string.
	 *
	 * @param string
	 * @param isUpper
	 * @return
	 */
	public String generateCharAndNumbers(String string, boolean isUpper) {
		return dataService.bothify(string, isUpper);
	}
	
	/**
	 * Generates a String that matches the given regular parseExpression.
	 */
	public String generateStringForRegEx(String regex) {
		return dataService.regexify(regex);
	}
	
	public RandomService random() {
		return this.randomService;
	}
	
	public DataService dataService() {
		return this.dataService;
	}
	
	public Name name() {
		return name;
	}
	
	public Number number() {
		return number;
	}
	
	public PhoneNumber phoneNumber() {
		return phoneNumber;
	}
	
	public Address address() {
		return address;
	}
	
	public Color color() {
		return color;
	}
	
	public SSNNumber ssn_number() {
		return ssn_number;
	}
	
	public String resolveData(String key) {
		if (key.equalsIgnoreCase("ssn_number")) {
			return this.ssn_number.ssnValid();
		} else {
			return this.dataService.resolve(key, this, this);
		}
	}
	
	/**
	 * Allows the evaluation of native YML parseExpressions to allow you to build your own.
	 * <p>
	 * The following are valid parseExpressions:
	 * <ul>
	 * <li>#{generateStringForRegEx '(a|b){2,3}'}</li>
	 * <li>#{generateStringForRegEx '\\.\\*\\?\\+'}</li>
	 * <li>#{generateCharAndNumbers '????','false'}</li>
	 * <li>#{Name.first_name} #{Name.first_name} #{Name.last_name}</li>
	 * <li>#{number.number_between '1','10'}</li>
	 * </ul>
	 *
	 * @param parseExpression
	 *            (see examples above)
	 * @return the evaluated string parseExpression
	 * @throws RuntimeException
	 *             if unable to evaluate the parseExpression
	 */
	public String parseExpression(String parseExpression) {
		return this.dataService.expression(parseExpression, this);
	}
	
	/**
	 * ###################################################################################
	 * 
	 * @Field : dateTime
	 * @Name : getDateTime
	 * @Purpose : TODO
	 * @Returns : DataGenerator
	 * @Author : Vaijnath
	 * @CreationDate : Feb 2, 2019 3:16:13 PM
	 * @Modification : NA
	 *               ###################################################################################
	 **/
	public DateAndTime getDateTime() {
		return dateTime;
	}
}
