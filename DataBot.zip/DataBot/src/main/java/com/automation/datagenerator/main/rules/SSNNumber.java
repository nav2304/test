package com.automation.datagenerator.main.rules;

import com.automation.datagenerator.idnumbers.SSNNumberRules;
import com.automation.datagenerator.main.DataGenerator;

public class SSNNumber {
	private final DataGenerator dataGenerator;
	
	public SSNNumber(DataGenerator dataGenerator, boolean repeatable) {
		this.dataGenerator = dataGenerator;
	}
	
	public String valid() {
		return dataGenerator.dataService().resolve("id_number.valid", this, dataGenerator);
	}
	
	public String invalid() {
		return dataGenerator.generateDigits(dataGenerator.dataService().resolve("id_number.invalid", this, dataGenerator));
	}
	
	public String ssnValid() {
		SSNNumberRules sSNNumberRules = new SSNNumberRules();
		return sSNNumberRules.getValidSsn(dataGenerator);
	}
}
